<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%
    // Tự động chuyển hướng về Servlet danh sách sản phẩm
    response.sendRedirect(request.getContextPath() + "/products");
%>

