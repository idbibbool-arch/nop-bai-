<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>
        <c:choose>
            <c:when test="${product != null}">Chỉnh Sửa Sản Phẩm</c:when>
            <c:otherwise>Thêm Sản Phẩm Mới</c:otherwise>
        </c:choose>
        - Quản Lý Sản Phẩm
    </title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body>

    <!-- Navigation Bar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow-sm">
        <div class="container">
            <a class="navbar-brand" href="${pageContext.request.contextPath}/products">
                <i class="fa-solid fa-boxes-stacked me-2 text-warning"></i> Quản Lý Sản Phẩm
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="${pageContext.request.contextPath}/products">
                            <i class="fa-solid fa-list me-1"></i> Danh Sách
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="${pageContext.request.contextPath}/products?action=new">
                            <i class="fa-solid fa-circle-plus me-1"></i> Thêm Sản Phẩm Mới
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="container mt-4">
        <div class="row justify-content-center">
            <div class="col-md-8 col-lg-6">

                <div class="card shadow-sm">
                    <div class="card-header ${product != null ? 'bg-warning text-dark' : 'bg-primary text-white'} py-3">
                        <h5 class="mb-0">
                            <i class="fa-solid ${product != null ? 'fa-pen-to-square' : 'fa-circle-plus'} me-2"></i>
                            <c:choose>
                                <c:when test="${product != null}">
                                    Chỉnh Sửa Sản Phẩm (ID: ${product.id})
                                </c:when>
                                <c:otherwise>
                                    Thêm Sản Phẩm Mới
                                </c:otherwise>
                            </c:choose>
                        </h5>
                    </div>

                    <div class="card-body p-4">
                        <form action="${pageContext.request.contextPath}/products" method="post" accept-charset="UTF-8">
                            
                            <!-- Định danh action gửi lên Servlet -->
                            <input type="hidden" name="action" value="${product != null ? 'update' : 'insert'}">
                            
                            <!-- Nếu là cập nhật thì truyền kèm ID sản phẩm -->
                            <c:if test="${product != null}">
                                <input type="hidden" name="id" value="${product.id}">
                            </c:if>

                            <!-- Tên sản phẩm -->
                            <div class="mb-3">
                                <label for="name" class="form-label">
                                    <i class="fa-solid fa-tag me-1 text-secondary"></i> Tên Sản Phẩm <span class="text-danger">*</span>
                                </label>
                                <input type="text" 
                                       class="form-control" 
                                       id="name" 
                                       name="name" 
                                       placeholder="Nhập tên sản phẩm (ví dụ: Bàn phím cơ)" 
                                       value="${product != null ? product.name : ''}" 
                                       required 
                                       maxlength="255">
                                <div class="form-text">Tên sản phẩm không được để trống.</div>
                            </div>

                            <!-- Đơn giá -->
                            <div class="mb-3">
                                <label for="price" class="form-label">
                                    <i class="fa-solid fa-money-bill-wave me-1 text-secondary"></i> Đơn Giá (VNĐ) <span class="text-danger">*</span>
                                </label>
                                <div class="input-group">
                                    <input type="number" 
                                           class="form-control" 
                                           id="price" 
                                           name="price" 
                                           placeholder="Ví dụ: 500000" 
                                           value="${product != null ? product.price : ''}" 
                                           required 
                                           min="0" 
                                           step="any">
                                    <span class="input-group-text">VNĐ</span>
                                </div>
                                <div class="form-text">Giá phải là số dương lớn hơn hoặc bằng 0.</div>
                            </div>

                            <!-- Số lượng -->
                            <div class="mb-4">
                                <label for="quantity" class="form-label">
                                    <i class="fa-solid fa-cubes-stacked me-1 text-secondary"></i> Số Lượng <span class="text-danger">*</span>
                                </label>
                                <input type="number" 
                                       class="form-control" 
                                       id="quantity" 
                                       name="quantity" 
                                       placeholder="Ví dụ: 10" 
                                       value="${product != null ? product.quantity : ''}" 
                                       required 
                                       min="0" 
                                       step="1">
                                <div class="form-text">Số lượng sản phẩm trong kho (số nguyên >= 0).</div>
                            </div>

                            <!-- Nút thao tác -->
                            <div class="d-flex justify-content-between align-items-center pt-2 border-top">
                                <a href="${pageContext.request.contextPath}/products" class="btn btn-outline-secondary">
                                    <i class="fa-solid fa-arrow-left me-1"></i> Quay lại
                                </a>
                                <button type="submit" class="btn ${product != null ? 'btn-warning text-dark' : 'btn-primary'} fw-bold px-4">
                                    <i class="fa-solid ${product != null ? 'fa-floppy-disk' : 'fa-check'} me-1"></i>
                                    <c:choose>
                                        <c:when test="${product != null}">Cập Nhật</c:when>
                                        <c:otherwise>Thêm Mới</c:otherwise>
                                    </c:choose>
                                </button>
                            </div>

                        </form>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <p class="mb-0">Bài Kiểm Tra Cuối Module: Phát Triển Ứng Dụng Web với JSP & Servlet</p>
        </div>
    </footer>

    <!-- Bootstrap 5 JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

