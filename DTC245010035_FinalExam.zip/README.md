# HỆ THỐNG QUẢN LÝ SẢN PHẨM (PRODUCT MANAGEMENT SYSTEM)
**Bài Kiểm Tra Cuối Module: Phát Triển Ứng Dụng Web với JSP & Servlet**

---

## 1. GIỚI THIỆU DỰ ÁN
Dự án được xây dựng theo mô hình kiến trúc **MVC (Model - View - Controller)** chuẩn mực trong Java Web:
- **Model**: Đại diện cho thực thể dữ liệu (`Product.java`).
- **DAO (Data Access Object)**: Quản lý kết nối JDBC và các thao tác CRUD dữ liệu với MySQL (`ProductDAO.java`, `DBConnection.java`).
- **Controller**: Tiếp nhận request từ người dùng, xử lý logic và điều phối luồng dữ liệu (`ProductServlet.java`).
- **View**: Hiển thị giao diện người dùng bằng JSP, JSTL, HTML5, CSS3 và Bootstrap 5 (`product-list.jsp`, `product-form.jsp`, `error.jsp`).

### Các Chức Năng Chính:
1. **Hiển thị danh sách sản phẩm**: Hiển thị bảng sản phẩm gồm ID, Tên sản phẩm, Đơn giá (định dạng tiền tệ VNĐ), Số lượng.
2. **Thêm sản phẩm mới**: Form nhập thông tin đầy đủ, kiểm tra dữ liệu và lưu vào cơ sở dữ liệu.
3. **Cập nhật sản phẩm**: Chọn sản phẩm cần sửa, form tự động đổ dữ liệu cũ để người dùng chỉnh sửa và cập nhật.
4. **Xóa sản phẩm**: Xóa sản phẩm khỏi CSDL với hộp thoại JavaScript xác nhận trước khi thực hiện xóa.
5. **Xử lý tiếng Việt**: Hỗ trợ đầy đủ bảng mã UTF-8 cả khi hiển thị và lưu vào MySQL.

---

## 2. CẤU TRÚC THƯ MỤC
```text
ProductManagement/
├── pom.xml                                       <- Cấu hình Maven Dependencies & Build
├── database.sql                                  <- Script tạo database và dữ liệu mẫu
├── README.md                                     <- Hướng dẫn cài đặt và chạy dự án
└── src/
    └── main/
        ├── java/
        │   └── com/
        │       └── exam/
        │           ├── model/
        │           │   └── Product.java          <- Entity Model Sản phẩm
        │           ├── dao/
        │           │   ├── DBConnection.java     <- Tiện ích kết nối MySQL JDBC
        │           │   └── ProductDAO.java       <- Các hàm CRUD truy vấn CSDL
        │           └── controller/
        │               └── ProductServlet.java   <- Servlet Controller điều phối CRUD
        └── webapp/
            ├── WEB-INF/
            │   └── web.xml                       <- Deployment Descriptor (cấu hình Servlet & Error)
            ├── css/
            │   └── style.css                     <- Tùy chỉnh giao diện
            ├── index.jsp                         <- Trang điều hướng mặc định vào /products
            ├── product-list.jsp                  <- Giao diện hiển thị danh sách sản phẩm
            ├── product-form.jsp                  <- Giao diện form Thêm mới & Chỉnh sửa
            └── error.jsp                         <- Trang thông báo lỗi thân thiện
```

---

## 3. HƯỚNG DẪN CÀI ĐẶT & CHẠY DỰ ÁN

### Bước 1: Khởi tạo Cơ Sở Dữ Liệu MySQL
1. Khởi động MySQL Server (sử dụng XAMPP, MySQL Server, hoặc Docker).
2. Mở công cụ quản lý CSDL (phpMyAdmin, MySQL Workbench, Navicat, DBeaver hoặc Terminal).
3. Mở và thực thi toàn bộ nội dung trong file `database.sql`.
   * Lệnh này sẽ tự động tạo cơ sở dữ liệu `product_management`, bảng `products` và nạp sẵn 7 sản phẩm mẫu.

### Bước 2: Cấu hình Kết nối CSDL trong Dự án
Mở file `src/main/java/com/exam/dao/DBConnection.java`, kiểm tra thông số kết nối:
```java
private static final String HOST = "localhost";
private static final String PORT = "3306";
private static final String DATABASE = "product_management";
private static final String USERNAME = "root";
private static final String PASSWORD = ""; // Đổi thành mật khẩu MySQL của bạn nếu có (ví dụ: "root" hoặc "123456")
```

---

### Bước 3: Hướng Dẫn Chạy Trên Các IDE Phổ Biến

#### Cách 1: Sử dụng Eclipse IDE
1. Mở Eclipse -> Chọn **File** -> **Import...** -> **Existing Maven Projects**.
2. Chọn thư mục dự án `ProductManagement` -> Nhấn **Finish**.
3. Cấu hình Tomcat: Vào tab **Servers** -> Nhấn chuột phải chọn **New** -> **Server** -> Chọn **Apache Tomcat v9.0** (hoặc v8.5 / v10) -> Trỏ tới thư mục Tomcat trên máy tính của bạn.
4. Nhấn chuột phải vào dự án `ProductManagement` -> Chọn **Run As** -> **Run on Server** -> Chọn Tomcat vừa tạo -> **Finish**.
5. Truy cập trình duyệt: `http://localhost:8080/ProductManagement/products`

#### Cách 2: Sử dụng IntelliJ IDEA (Ultimate)
1. Mở IntelliJ -> Chọn **Open** -> Chọn thư mục `ProductManagement` (chọn mở dưới dạng Maven Project).
2. Vào **Run/Debug Configurations** -> Nhấn dấu **+** -> Chọn **Tomcat Server** -> **Local**.
3. Tại tab **Deployment**, nhấn **+** -> Chọn **Artifact** -> Chọn `ProductManagement:war exploded`.
4. Đặt Application context là `/ProductManagement`.
5. Nhấn **Run** hoặc **Debug** để khởi động Tomcat.

#### Cách 3: Sử dụng NetBeans IDE
1. Mở NetBeans -> Chọn **File** -> **Open Project**.
2. NetBeans sẽ tự động nhận diện dự án Maven với biểu tượng quả cầu web.
3. Nhấn chuột phải vào dự án -> Chọn **Properties** -> mục **Run** -> Chọn Server là Tomcat.
4. Nhấn nút **Run** (F6) để tự động build và chạy trên Tomcat.

#### Cách 4: Build và Deploy bằng Maven CLI
Nếu trên máy đã cài đặt Maven và Tomcat:
1. Mở Terminal tại thư mục `ProductManagement`:
   ```bash
   mvn clean package
   ```
2. Sau khi build thành công, file `ProductManagement.war` sẽ nằm trong thư mục `target/`.
3. Sao chép file `ProductManagement.war` vào thư mục `webapps` của Apache Tomcat.
4. Khởi động Tomcat bằng `bin/startup.bat` (trên Windows) hoặc `bin/startup.sh` (trên Linux/macOS).
5. Mở trình duyệt truy cập: `http://localhost:8080/ProductManagement/products`

---

## 4. HƯỚNG DẪN NỘP BÀI (ĐÓNG GÓI FILE ZIP)

Theo yêu cầu của đề bài:
> Tên file nộp: `[Mã_số_sinh_viên]_FinalExam.zip`

**Ví dụ:** Mã số sinh viên của bạn là `B21DCCN123`, tên file sẽ là:
```text
B21DCCN123_FinalExam.zip
```

**Các bước nộp bài:**
1. Đảm bảo file `database.sql` nằm ở thư mục gốc của dự án.
2. Nén toàn bộ thư mục `ProductManagement` (hoặc đổi tên thư mục thành `B21DCCN123_FinalExam` trước khi nén).
3. Kiểm tra file nén chứa đầy đủ mã nguồn `src/`, `pom.xml`, `database.sql` và `README.md`.

