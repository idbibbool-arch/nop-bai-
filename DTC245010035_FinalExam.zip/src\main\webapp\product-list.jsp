<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/fmt" prefix="fmt" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Danh Sách Sản Phẩm - Quản Lý Sản Phẩm</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body>

    <!-- Navigation Bar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow-sm">
        <div class="container">
            <a class="navbar-brand" href="${pageContext.request.contextPath}/products">
                <i class="fa-solid fa-boxes-stacked me-2 text-warning"></i> Quản Lý Sản Phẩm
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link active" href="${pageContext.request.contextPath}/products">
                            <i class="fa-solid fa-list me-1"></i> Danh Sách
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="${pageContext.request.contextPath}/products?action=new">
                            <i class="fa-solid fa-circle-plus me-1"></i> Thêm Sản Phẩm Mới
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="container mt-4">

        <!-- Thông báo thao tác (Flash message) -->
        <c:if test="${param.msg == 'inserted'}">
            <div class="alert alert-success alert-dismissible fade show shadow-sm" role="alert">
                <i class="fa-solid fa-circle-check me-2"></i> Thêm sản phẩm mới thành công!
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        </c:if>
        <c:if test="${param.msg == 'updated'}">
            <div class="alert alert-info alert-dismissible fade show shadow-sm" role="alert">
                <i class="fa-solid fa-circle-check me-2"></i> Cập nhật thông tin sản phẩm thành công!
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        </c:if>
        <c:if test="${param.msg == 'deleted'}">
            <div class="alert alert-warning alert-dismissible fade show shadow-sm" role="alert">
                <i class="fa-solid fa-trash-can me-2"></i> Xóa sản phẩm thành công!
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        </c:if>
        <c:if test="${not empty param.err}">
            <div class="alert alert-danger alert-dismissible fade show shadow-sm" role="alert">
                <i class="fa-solid fa-triangle-exclamation me-2"></i> Đã xảy ra lỗi trong quá trình thực hiện!
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        </c:if>

        <!-- Card danh sách sản phẩm -->
        <div class="card shadow-sm">
            <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center py-3">
                <h5 class="mb-0">
                    <i class="fa-solid fa-table-list me-2"></i> Danh Sách Sản Phẩm
                </h5>
                <a href="${pageContext.request.contextPath}/products?action=new" class="btn btn-light btn-sm fw-bold shadow-sm">
                    <i class="fa-solid fa-plus text-primary me-1"></i> Thêm Sản Phẩm Mới
                </a>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover table-striped mb-0">
                        <thead class="table-dark">
                            <tr>
                                <th class="text-center" style="width: 80px;">ID</th>
                                <th>Tên Sản Phẩm</th>
                                <th class="text-end" style="width: 180px;">Đơn Giá (VNĐ)</th>
                                <th class="text-center" style="width: 130px;">Số Lượng</th>
                                <th class="text-center" style="width: 180px;">Thao Tác</th>
                            </tr>
                        </thead>
                        <tbody>
                            <c:choose>
                                <c:when test="${not empty listProduct}">
                                    <c:forEach var="product" items="${listProduct}">
                                        <tr>
                                            <td class="text-center fw-bold text-muted">${product.id}</td>
                                            <td>
                                                <span class="fw-semibold text-dark">${product.name}</span>
                                            </td>
                                            <td class="text-end text-success fw-bold">
                                                <fmt:formatNumber value="${product.price}" type="currency" currencySymbol="₫" maxFractionDigits="0"/>
                                            </td>
                                            <td class="text-center">
                                                <c:choose>
                                                    <c:when test="${product.quantity <= 5}">
                                                        <span class="badge bg-danger rounded-pill px-3">${product.quantity} (Ít)</span>
                                                    </c:when>
                                                    <c:otherwise>
                                                        <span class="badge bg-success rounded-pill px-3">${product.quantity}</span>
                                                    </c:otherwise>
                                                </c:choose>
                                            </td>
                                            <td class="text-center">
                                                <a href="${pageContext.request.contextPath}/products?action=edit&id=${product.id}" 
                                                   class="btn btn-warning btn-sm btn-action text-dark shadow-sm"
                                                   title="Sửa sản phẩm">
                                                    <i class="fa-solid fa-pen-to-square"></i> Sửa
                                                </a>
                                                <a href="${pageContext.request.contextPath}/products?action=delete&id=${product.id}" 
                                                   class="btn btn-danger btn-sm btn-action shadow-sm"
                                                   onclick="return confirm('Bạn có chắc chắn muốn xóa sản phẩm &quot;${product.name}&quot; (ID: ${product.id}) không?');"
                                                   title="Xóa sản phẩm">
                                                    <i class="fa-solid fa-trash"></i> Xóa
                                                </a>
                                            </td>
                                        </tr>
                                    </c:forEach>
                                </c:when>
                                <c:otherwise>
                                    <tr>
                                        <td colspan="5" class="text-center py-5 text-muted">
                                            <i class="fa-solid fa-box-open fa-3x mb-3 text-secondary"></i>
                                            <p class="mb-0">Chưa có sản phẩm nào trong hệ thống.</p>
                                            <a href="${pageContext.request.contextPath}/products?action=new" class="btn btn-primary btn-sm mt-3">
                                                <i class="fa-solid fa-plus me-1"></i> Thêm sản phẩm đầu tiên
                                            </a>
                                        </td>
                                    </tr>
                                </c:otherwise>
                            </c:choose>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="card-footer bg-light text-muted d-flex justify-content-between align-items-center py-2">
                <small>Tổng cộng: <strong>${listProduct != null ? listProduct.size() : 0}</strong> sản phẩm</small>
            </div>
        </div>

    </div>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <p class="mb-0">Bài Kiểm Tra Cuối Module: Phát Triển Ứng Dụng Web với JSP & Servlet</p>
        </div>
    </footer>

    <!-- Bootstrap 5 JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

