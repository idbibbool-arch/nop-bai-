-- ==============================================================
-- DATABASE CREATION SCRIPT: product_management
-- BÀI KIỂM TRA CUỐI MODULE: PHÁT TRIỂN ỨNG DỤNG WEB VỚI JSP & SERVLET
-- ==============================================================

CREATE DATABASE IF NOT EXISTS product_management 
CHARACTER SET utf8mb4 
COLLATE utf8mb4_unicode_ci;

USE product_management;

-- Tạo bảng products
DROP TABLE IF EXISTS products;

CREATE TABLE products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    price DOUBLE NOT NULL,
    quantity INT NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Thêm dữ liệu mẫu ban đầu
INSERT INTO products (name, price, quantity) VALUES
('Laptop Dell Inspiron 15', 16500000, 15),
('Chuột không dây Logitech M331', 320000, 50),
('Bàn phím cơ DareU EK87', 650000, 30),
('Màn hình LG 24 inch IPS 75Hz', 2890000, 20),
('Tai nghe gaming Sony WH-1000XM4', 5990000, 10),
('Ổ cứng di động SSD Kingston 1TB', 1850000, 25),
('Webcam FullHD Logitech C920', 1450000, 12);

-- Kiểm tra dữ liệu đã thêm
SELECT * FROM products;

