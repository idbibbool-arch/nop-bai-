<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isErrorPage="true" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thông Báo Lỗi - Quản Lý Sản Phẩm</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body class="d-flex flex-column min-vh-100">

    <!-- Navigation Bar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow-sm">
        <div class="container">
            <a class="navbar-brand" href="${pageContext.request.contextPath}/products">
                <i class="fa-solid fa-boxes-stacked me-2 text-warning"></i> Quản Lý Sản Phẩm
            </a>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="container my-auto py-5">
        <div class="row justify-content-center">
            <div class="col-md-7 col-lg-5 text-center">
                <div class="card shadow p-4 border-0">
                    <div class="mb-3 text-danger">
                        <i class="fa-solid fa-circle-exclamation fa-4x"></i>
                    </div>
                    <h3 class="fw-bold text-dark mb-2">Đã Có Lỗi Xảy Ra!</h3>
                    <p class="text-muted mb-4">
                        <c:choose>
                            <c:when test="${not empty errorMessage}">
                                ${errorMessage}
                            </c:when>
                            <c:when test="${not empty exception}">
                                ${exception.message}
                            </c:when>
                            <c:otherwise>
                                Trang bạn đang tìm kiếm không tồn tại hoặc đã xảy ra lỗi trong quá trình xử lý yêu cầu.
                            </c:otherwise>
                        </c:choose>
                    </p>
                    <div>
                        <a href="${pageContext.request.contextPath}/products" class="btn btn-primary px-4 py-2">
                            <i class="fa-solid fa-house me-1"></i> Quay lại Danh sách Sản phẩm
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="footer mt-auto">
        <div class="container">
            <p class="mb-0">Bài Kiểm Tra Cuối Module: Phát Triển Ứng Dụng Web với JSP & Servlet</p>
        </div>
    </footer>

    <!-- Bootstrap 5 JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

