package com.exam.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Lớp tiện ích cung cấp kết nối JDBC tới cơ sở dữ liệu MySQL
 */
public class DBConnection {

    // Thông số cấu hình kết nối MySQL (Có thể thay đổi mật khẩu tùy theo môi trường của bạn)
    private static final String HOST = "localhost";
    private static final String PORT = "3306";
    private static final String DATABASE = "product_management";
    private static final String USERNAME = "root";
    private static final String PASSWORD = ""; // Đặt mật khẩu MySQL nếu có (ví dụ: "root" hoặc "123456")

    // URL kết nối hỗ trợ mã hóa UTF-8 tiếng Việt và múi giờ
    private static final String JDBC_URL = "jdbc:mysql://" + HOST + ":" + PORT + "/" + DATABASE 
            + "?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true&useUnicode=true&characterEncoding=UTF-8";

    static {
        try {
            // Nạp MySQL JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            System.err.println("Không tìm thấy MySQL Driver: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Mở và trả về đối tượng kết nối Connection
     * @return Connection hoặc null nếu kết nối thất bại
     * @throws SQLException nếu có lỗi kết nối
     */
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);
    }
}

